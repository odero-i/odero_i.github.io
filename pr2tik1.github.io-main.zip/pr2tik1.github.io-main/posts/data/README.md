`cps_85_wages.csv` is available at https://www.openml.org/d/534
`adult-census.csv` is available at https://www.openml.org/d/15950
